package Something2Else.initfwd.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import Something2Else.initfwd.hipe.engine.actor.NotificationActor;
import Something2Else.initfwd.hipe.engine.actor.DispatchActor;
import Something2Else.initfwd.hipe.engine.actor.localsearch.ComponentToEntity__CONSISTENCY_1_localSearch;
import Something2Else.initfwd.hipe.engine.actor.localsearch.SystemToRoot__CONSISTENCY_7_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ComponentToEntity__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("ComponentToEntity__CONSISTENCY_production", "ComponentToEntity__CONSISTENCY");
		classes.put("ComponentToEntity__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ComponentToEntity__FWD_production", "ComponentToEntity__FWD");
		classes.put("SystemToRoot__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("SystemToRoot__CONSISTENCY_production", "SystemToRoot__CONSISTENCY");
		classes.put("SystemToRoot__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("SystemToRoot__FWD_production", "SystemToRoot__FWD");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ComponentToEntity__CONSISTENCY_1_localSearch", ComponentToEntity__CONSISTENCY_1_localSearch.class);
		classes.put("SystemToRoot__CONSISTENCY_7_localSearch", SystemToRoot__CONSISTENCY_7_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("Component_object",Component_object.class);
		classes.put("Entity_object",Entity_object.class);
		classes.put("ComponentToEntity_object",ComponentToEntity_object.class);
		classes.put("ComponentToEntity__Marker_object",ComponentToEntity__Marker_object.class);
		classes.put("System_object",System_object.class);
		classes.put("Root_object",Root_object.class);
		classes.put("SystemToRoot_object",SystemToRoot_object.class);
		classes.put("SystemToRoot__Marker_object",SystemToRoot__Marker_object.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class Component_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model.Component> { }
class Entity_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model2.Entity> { }
class ComponentToEntity_object extends GenericObjectActor<Something2Else.ComponentToEntity> { }
class ComponentToEntity__Marker_object extends GenericObjectActor<Something2Else.ComponentToEntity__Marker> { }
class System_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model.System> { }
class Root_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model2.Root> { }
class SystemToRoot_object extends GenericObjectActor<Something2Else.SystemToRoot> { }
class SystemToRoot__Marker_object extends GenericObjectActor<Something2Else.SystemToRoot__Marker> { }


