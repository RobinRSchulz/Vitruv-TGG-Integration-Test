package Something2Else.co.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import Something2Else.co.hipe.engine.actor.NotificationActor;
import Something2Else.co.hipe.engine.actor.DispatchActor;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ComponentToEntity__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ComponentToEntity__CC_production", "ComponentToEntity__CC");
		classes.put("SystemToRoot__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("SystemToRoot__CC_production", "SystemToRoot__CC");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ComponentToEntity__CC_1_junction", GenericJunctionActor.class);
		classes.put("SystemToRoot__CC_4_junction", GenericJunctionActor.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("Component_object",Component_object.class);
		classes.put("Entity_object",Entity_object.class);
		classes.put("System_object",System_object.class);
		classes.put("Root_object",Root_object.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class Component_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model.Component> { }
class Entity_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model2.Entity> { }
class System_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model.System> { }
class Root_object extends GenericObjectActor<tools.vitruv.methodologisttemplate.model.model2.Root> { }


