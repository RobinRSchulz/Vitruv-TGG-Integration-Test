package Something2Else.co.hipe.engine.actor;

import java.util.Collection;
import java.util.LinkedList;

import org.eclipse.emf.ecore.EObject;

import akka.actor.ActorRef;

import hipe.engine.actor.GenericNotificationActor;
import hipe.engine.util.IncUtil;

public class NotificationActor extends GenericNotificationActor {
	
	public NotificationActor(ActorRef dispatchActor, IncUtil incUtil, boolean cascadingNotifications) {
		super(dispatchActor, incUtil, cascadingNotifications);
	}
	
	@Override
	protected void initializeExploration() {
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model.ModelPackage.eINSTANCE.getServer(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model.ModelPackage.eINSTANCE.getProtocol(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model2.Model2Package.eINSTANCE.getEntity(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model.ModelPackage.eINSTANCE.getLink(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model2.Model2Package.eINSTANCE.getLink(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model2.Model2Package.eINSTANCE.getRoot(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			tools.vitruv.methodologisttemplate.model.model2.Root _root = (tools.vitruv.methodologisttemplate.model.model2.Root) obj;
			children.addAll(_root.getEntities());
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model.ModelPackage.eINSTANCE.getSystem(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			tools.vitruv.methodologisttemplate.model.model.System _system = (tools.vitruv.methodologisttemplate.model.model.System) obj;
			children.addAll(_system.getLinks());
			children.addAll(_system.getComponents());
			children.addAll(_system.getProtocols());
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model.ModelPackage.eINSTANCE.getComponent(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(tools.vitruv.methodologisttemplate.model.model.ModelPackage.eINSTANCE.getDevice(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
	}
}

