package Something2Else.impl;

import Something2Else.SystemToRoot;
import Something2Else.ComponentToEntity;
import Something2Else.ComponentToEntity__Marker;
import Something2Else.SystemToRoot__Marker;


import Something2Else.Something2ElseFactory;
import Something2Else.Something2ElsePackage;

import tools.vitruv.methodologisttemplate.model.model.ModelPackage;
import tools.vitruv.methodologisttemplate.model.model2.Model2Package;
import runtime.RuntimePackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class Something2ElsePackageImpl extends SmartPackageImpl
		implements Something2ElsePackage {
			
	private EClass systemToRootEClass = null;
	private EReference systemToRoot_sourceEReference = null;
	private EReference systemToRoot_targetEReference = null;
	private EClass componentToEntityEClass = null;
	private EReference componentToEntity_sourceEReference = null;
	private EReference componentToEntity_targetEReference = null;
	private EClass componentToEntity__MarkerEClass = null;
	private EReference componentToEntity__Marker_cREATE__SRC__compEReference = null;
	private EReference componentToEntity__Marker_cREATE__TRG__entityEReference = null;
	private EReference componentToEntity__Marker_cREATE__CORR__ctoeEReference = null;
	private EClass systemToRoot__MarkerEClass = null;
	private EReference systemToRoot__Marker_cREATE__SRC__systemEReference = null;
	private EReference systemToRoot__Marker_cREATE__TRG__rootEReference = null;
	private EReference systemToRoot__Marker_cREATE__CORR__storEReference = null;
	
	

	private Something2ElsePackageImpl() {
		super(eNS_URI, Something2Else.Something2ElseFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static Something2ElsePackage init() {
		if (isRegistered)
			return (Something2ElsePackage) EPackage.Registry.INSTANCE
					.getEPackage(Something2ElsePackage.eNS_URI);

		// Obtain or create and register package
		Object registeredSomething2ElsePackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		Something2ElsePackageImpl theSomething2ElsePackage = registeredSomething2ElsePackage instanceof Something2ElsePackageImpl
				? (Something2ElsePackageImpl) registeredSomething2ElsePackage
				: new Something2ElsePackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theSomething2ElsePackage.createPackageContents();

		// Initialize created meta-data
		theSomething2ElsePackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theSomething2ElsePackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theSomething2ElsePackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theSomething2ElsePackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Something2ElsePackage.eNS_URI,
				theSomething2ElsePackage);
				
		theSomething2ElsePackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theSomething2ElsePackage;
	}

	@Override
	public EClass getSystemToRoot() {
		return systemToRootEClass;
	}
	@Override
	public EReference getSystemToRoot_Source() {
		return systemToRoot_sourceEReference;	
	}
	@Override
	public EReference getSystemToRoot_Target() {
		return systemToRoot_targetEReference;	
	}
	@Override
	public EClass getComponentToEntity() {
		return componentToEntityEClass;
	}
	@Override
	public EReference getComponentToEntity_Source() {
		return componentToEntity_sourceEReference;	
	}
	@Override
	public EReference getComponentToEntity_Target() {
		return componentToEntity_targetEReference;	
	}
	@Override
	public EClass getComponentToEntity__Marker() {
		return componentToEntity__MarkerEClass;
	}
	@Override
	public EReference getComponentToEntity__Marker_CREATE__SRC__comp() {
		return componentToEntity__Marker_cREATE__SRC__compEReference;	
	}
	@Override
	public EReference getComponentToEntity__Marker_CREATE__TRG__entity() {
		return componentToEntity__Marker_cREATE__TRG__entityEReference;	
	}
	@Override
	public EReference getComponentToEntity__Marker_CREATE__CORR__ctoe() {
		return componentToEntity__Marker_cREATE__CORR__ctoeEReference;	
	}
	@Override
	public EClass getSystemToRoot__Marker() {
		return systemToRoot__MarkerEClass;
	}
	@Override
	public EReference getSystemToRoot__Marker_CREATE__SRC__system() {
		return systemToRoot__Marker_cREATE__SRC__systemEReference;	
	}
	@Override
	public EReference getSystemToRoot__Marker_CREATE__TRG__root() {
		return systemToRoot__Marker_cREATE__TRG__rootEReference;	
	}
	@Override
	public EReference getSystemToRoot__Marker_CREATE__CORR__stor() {
		return systemToRoot__Marker_cREATE__CORR__storEReference;	
	}
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Something2Else.Something2ElseFactory getSomething2ElseFactory() {
		return (Something2Else.Something2ElseFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		systemToRootEClass = createEClass(SYSTEM_TO_ROOT);
		createEReference(systemToRootEClass, SYSTEM_TO_ROOT__SOURCE);
		systemToRoot_sourceEReference = (EReference) systemToRootEClass.getEStructuralFeatures().get(0);
		createEReference(systemToRootEClass, SYSTEM_TO_ROOT__TARGET);
		systemToRoot_targetEReference = (EReference) systemToRootEClass.getEStructuralFeatures().get(1);
		
		componentToEntityEClass = createEClass(COMPONENT_TO_ENTITY);
		createEReference(componentToEntityEClass, COMPONENT_TO_ENTITY__SOURCE);
		componentToEntity_sourceEReference = (EReference) componentToEntityEClass.getEStructuralFeatures().get(0);
		createEReference(componentToEntityEClass, COMPONENT_TO_ENTITY__TARGET);
		componentToEntity_targetEReference = (EReference) componentToEntityEClass.getEStructuralFeatures().get(1);
		
		componentToEntity__MarkerEClass = createEClass(COMPONENT_TO_ENTITY___MARKER);
		createEReference(componentToEntity__MarkerEClass, COMPONENT_TO_ENTITY___MARKER__CREAT_E__SR_C__COMP);
		componentToEntity__Marker_cREATE__SRC__compEReference = (EReference) componentToEntity__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(componentToEntity__MarkerEClass, COMPONENT_TO_ENTITY___MARKER__CREAT_E__TR_G__ENTITY);
		componentToEntity__Marker_cREATE__TRG__entityEReference = (EReference) componentToEntity__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(componentToEntity__MarkerEClass, COMPONENT_TO_ENTITY___MARKER__CREAT_E__COR_R__CTOE);
		componentToEntity__Marker_cREATE__CORR__ctoeEReference = (EReference) componentToEntity__MarkerEClass.getEStructuralFeatures().get(2);
		
		systemToRoot__MarkerEClass = createEClass(SYSTEM_TO_ROOT___MARKER);
		createEReference(systemToRoot__MarkerEClass, SYSTEM_TO_ROOT___MARKER__CREAT_E__SR_C__SYSTEM);
		systemToRoot__Marker_cREATE__SRC__systemEReference = (EReference) systemToRoot__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(systemToRoot__MarkerEClass, SYSTEM_TO_ROOT___MARKER__CREAT_E__TR_G__ROOT);
		systemToRoot__Marker_cREATE__TRG__rootEReference = (EReference) systemToRoot__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(systemToRoot__MarkerEClass, SYSTEM_TO_ROOT___MARKER__CREAT_E__COR_R__STOR);
		systemToRoot__Marker_cREATE__CORR__storEReference = (EReference) systemToRoot__MarkerEClass.getEStructuralFeatures().get(2);
		
		// Create enums
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages
		ModelPackage theModelPackagePackage = ModelPackage.eINSTANCE;
		Model2Package theModel2PackagePackage = Model2Package.eINSTANCE;
		RuntimePackage theRuntimePackagePackage = RuntimePackage.eINSTANCE;

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		systemToRootEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		componentToEntityEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		componentToEntity__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		systemToRoot__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());

		// Initialize classes, features, and operations; add parameters
		initEClass(systemToRootEClass, SystemToRoot.class, "SystemToRoot", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSystemToRoot_Source(), ModelPackage.eINSTANCE.getSystem(),  null, 
			"source", null, 0, 1, SystemToRoot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemToRoot_Target(), Model2Package.eINSTANCE.getRoot(),  null, 
			"target", null, 0, 1, SystemToRoot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(componentToEntityEClass, ComponentToEntity.class, "ComponentToEntity", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getComponentToEntity_Source(), ModelPackage.eINSTANCE.getComponent(),  null, 
			"source", null, 0, 1, ComponentToEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getComponentToEntity_Target(), Model2Package.eINSTANCE.getEntity(),  null, 
			"target", null, 0, 1, ComponentToEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(componentToEntity__MarkerEClass, ComponentToEntity__Marker.class, "ComponentToEntity__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getComponentToEntity__Marker_CREATE__SRC__comp(), ModelPackage.eINSTANCE.getComponent(),  null, 
			"CREATE__SRC__comp", null, 1, 1, ComponentToEntity__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getComponentToEntity__Marker_CREATE__TRG__entity(), Model2Package.eINSTANCE.getEntity(),  null, 
			"CREATE__TRG__entity", null, 1, 1, ComponentToEntity__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getComponentToEntity__Marker_CREATE__CORR__ctoe(), this.getComponentToEntity(),  null, 
			"CREATE__CORR__ctoe", null, 1, 1, ComponentToEntity__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(systemToRoot__MarkerEClass, SystemToRoot__Marker.class, "SystemToRoot__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSystemToRoot__Marker_CREATE__SRC__system(), ModelPackage.eINSTANCE.getSystem(),  null, 
			"CREATE__SRC__system", null, 1, 1, SystemToRoot__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemToRoot__Marker_CREATE__TRG__root(), Model2Package.eINSTANCE.getRoot(),  null, 
			"CREATE__TRG__root", null, 1, 1, SystemToRoot__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemToRoot__Marker_CREATE__CORR__stor(), this.getSystemToRoot(),  null, 
			"CREATE__CORR__stor", null, 1, 1, SystemToRoot__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		
		// Initialize enums and add enum literals
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

