package Something2Else;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface Something2ElsePackage extends SmartPackage {

	String eNAME = "Something2Else";
	String eNS_URI = "platform:/resource/Something2Else/model/Something2Else.ecore";
	String eNS_PREFIX = "Something2Else";

	Something2ElsePackage eINSTANCE = Something2Else.impl.Something2ElsePackageImpl.init();

	int SYSTEM_TO_ROOT = 0;
	int SYSTEM_TO_ROOT__SOURCE = 0;
	int SYSTEM_TO_ROOT__TARGET = 1;
	int SYSTEM_TO_ROOT_FEATURE_COUNT = 2;
	int SYSTEM_TO_ROOT_OPERATION_COUNT = 0;
	
	int SYSTEM_TO_ROOT___MARKER = 1;
	int SYSTEM_TO_ROOT___MARKER__CREAT_E__SR_C__SYSTEM = 2;
	int SYSTEM_TO_ROOT___MARKER__CREAT_E__TR_G__ROOT = 3;
	int SYSTEM_TO_ROOT___MARKER__CREAT_E__COR_R__STOR = 4;
	int SYSTEM_TO_ROOT___MARKER_FEATURE_COUNT = 4;
	int SYSTEM_TO_ROOT___MARKER_OPERATION_COUNT = 0;
	
	

	EClass getSystemToRoot();
	EReference getSystemToRoot_Source();
	EReference getSystemToRoot_Target();
	
	EClass getSystemToRoot__Marker();
	EReference getSystemToRoot__Marker_CREATE__SRC__system();
	EReference getSystemToRoot__Marker_CREATE__TRG__root();
	EReference getSystemToRoot__Marker_CREATE__CORR__stor();
	
	
	Something2Else.Something2ElseFactory getSomething2ElseFactory();

	interface Literals {
		
		EClass SYSTEM_TO_ROOT = eINSTANCE.getSystemToRoot();
		
		EReference SYSTEM_TO_ROOT__SOURCE = eINSTANCE.getSystemToRoot_Source();
		
		EReference SYSTEM_TO_ROOT__TARGET = eINSTANCE.getSystemToRoot_Target();
		
		EClass SYSTEM_TO_ROOT___MARKER = eINSTANCE.getSystemToRoot__Marker();
		
		EReference SYSTEM_TO_ROOT___MARKER__CREAT_E__SR_C__SYSTEM = eINSTANCE.getSystemToRoot__Marker_CREATE__SRC__system();
		
		EReference SYSTEM_TO_ROOT___MARKER__CREAT_E__TR_G__ROOT = eINSTANCE.getSystemToRoot__Marker_CREATE__TRG__root();
		
		EReference SYSTEM_TO_ROOT___MARKER__CREAT_E__COR_R__STOR = eINSTANCE.getSystemToRoot__Marker_CREATE__CORR__stor();
		
		
		
		
	}

} 
