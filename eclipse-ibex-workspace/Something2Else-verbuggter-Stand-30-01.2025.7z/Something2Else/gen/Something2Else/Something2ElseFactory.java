package Something2Else;

import Something2Else.SystemToRoot;
import Something2Else.SystemToRoot__Marker;

import org.eclipse.emf.ecore.EFactory;

public interface Something2ElseFactory extends EFactory {

	Something2ElseFactory eINSTANCE = Something2Else.impl.Something2ElseFactoryImpl.init();
	
	SystemToRoot createSystemToRoot();
	
	SystemToRoot__Marker createSystemToRoot__Marker();
	
	
	Something2ElsePackage getSomething2ElsePackage();

}
